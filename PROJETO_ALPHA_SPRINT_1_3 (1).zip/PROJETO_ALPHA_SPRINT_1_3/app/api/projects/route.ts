import {NextResponse} from "next/server";import {projects} from "@/lib/projects";export async function GET(){return NextResponse.json({data:projects,total:projects.length})}
