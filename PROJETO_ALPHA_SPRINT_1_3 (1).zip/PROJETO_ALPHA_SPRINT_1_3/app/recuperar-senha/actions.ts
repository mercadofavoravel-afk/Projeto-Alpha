"use server";
import { redirect } from "next/navigation";
import { createPasswordReset } from "@/lib/auth";

export async function requestResetAction(formData: FormData) {
  const email = String(formData.get("email") ?? "");
  const token = await createPasswordReset(email);
  // Em produção, envie o link por um provedor transacional. O token nunca deve ser exibido.
  if (process.env.NODE_ENV !== "production" && token) redirect(`/redefinir-senha?token=${encodeURIComponent(token)}`);
  redirect("/recuperar-senha?sent=1");
}
