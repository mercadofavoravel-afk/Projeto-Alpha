import { describe, expect, it } from "vitest";
import { calculateSeoScore } from "./score";

describe("calculateSeoScore", () => {
  it("retorna 100 para um documento completo", () => {
    const result = calculateSeoScore({
      name: "Ipanema",
      slug: "ipanema",
      heroImage: "/images/ipanema.jpg",
      seoTitle: "Imóveis de luxo em Ipanema no Rio de Janeiro",
      seoDescription: "Conheça imóveis de alto padrão em Ipanema, com curadoria especializada, localização privilegiada e atendimento consultivo no Rio de Janeiro.",
      description: "Ipanema reúne praia, mobilidade, gastronomia e uma oferta imobiliária de alto padrão reconhecida internacionalmente, com opções para moradia e investimento.",
    });
    expect(result.score).toBe(100);
  });

  it("identifica conteúdo sem preparação SEO", () => {
    expect(calculateSeoScore({ name: "X", slug: "Slug Inválido" }).score).toBe(0);
  });
});
