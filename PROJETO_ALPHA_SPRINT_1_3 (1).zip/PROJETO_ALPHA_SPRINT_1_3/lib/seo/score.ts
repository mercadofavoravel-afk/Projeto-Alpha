type SeoDocument = {
  name?: string | null;
  description?: string | null;
  heroImage?: string | null;
  seoTitle?: string | null;
  seoDescription?: string | null;
  slug?: string | null;
};

export type SeoCheck = { label: string; points: number; passed: boolean };

export function calculateSeoScore(document: SeoDocument) {
  const checks: SeoCheck[] = [
    { label: "Título SEO entre 30 e 60 caracteres", points: 20, passed: between(document.seoTitle, 30, 60) },
    { label: "Descrição SEO entre 120 e 160 caracteres", points: 20, passed: between(document.seoDescription, 120, 160) },
    { label: "Descrição editorial com pelo menos 120 caracteres", points: 20, passed: (document.description?.trim().length ?? 0) >= 120 },
    { label: "Imagem principal cadastrada", points: 15, passed: Boolean(document.heroImage?.trim()) },
    { label: "Slug limpo e legível", points: 15, passed: Boolean(document.slug && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(document.slug)) },
    { label: "Nome principal cadastrado", points: 10, passed: (document.name?.trim().length ?? 0) >= 3 },
  ];

  return {
    score: checks.reduce((total, check) => total + (check.passed ? check.points : 0), 0),
    checks,
  };
}

function between(value: string | null | undefined, min: number, max: number) {
  const length = value?.trim().length ?? 0;
  return length >= min && length <= max;
}
