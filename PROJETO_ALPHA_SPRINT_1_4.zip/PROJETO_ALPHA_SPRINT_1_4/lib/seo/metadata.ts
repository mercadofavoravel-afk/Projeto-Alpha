import type { Metadata } from "next";
import { buildCanonical } from "./canonical";
import type { MetadataOptions } from "./types";

function resolveImage(image?: string | null) {
  if (!image) return undefined;
  if (/^https?:\/\//.test(image)) return image;
  return buildCanonical(image);
}

export function createMetadata(options: MetadataOptions): Metadata {
  const canonical = buildCanonical(options.path);
  const image = resolveImage(options.image);

  return {
    title: options.title,
    description: options.description,
    keywords: options.keywords,
    alternates: { canonical },
    robots: options.noIndex
      ? { index: false, follow: false }
      : { index: true, follow: true },
    openGraph: {
      type: "website",
      locale: "pt_BR",
      title: options.title,
      description: options.description,
      url: canonical,
      images: image ? [{ url: image }] : undefined,
    },
    twitter: {
      card: image ? "summary_large_image" : "summary",
      title: options.title,
      description: options.description,
      images: image ? [image] : undefined,
    },
  };
}
